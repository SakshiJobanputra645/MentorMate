package com.example.finalmentormate.Adapters;

public interface InterfaceDoubtClick {
    void onClick(int p);
}