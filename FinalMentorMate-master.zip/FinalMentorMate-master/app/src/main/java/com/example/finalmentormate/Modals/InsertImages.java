package com.example.finalmentormate.Modals;

public class InsertImages {

    String image;

    public InsertImages(String image) {
        this.image = image;
    }

    public String getImage() {
        return image;
    }
}
