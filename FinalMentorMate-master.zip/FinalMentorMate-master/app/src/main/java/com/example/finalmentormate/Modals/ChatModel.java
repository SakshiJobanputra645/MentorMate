package com.example.finalmentormate.Modals;

public class ChatModel {



}
